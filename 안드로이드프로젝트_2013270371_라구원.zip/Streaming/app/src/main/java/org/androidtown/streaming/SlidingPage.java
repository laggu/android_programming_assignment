package org.androidtown.streaming;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

/**
 * Created by laggu on 2017-06-23.
 */

public class SlidingPage extends LinearLayout {
    Animation leftAnim, rightAnim;
    boolean isPageOpen = false;

    EditText redText, yellowText, blueText;
    Button sendingButton;

    SocketClient socket;

    SlidingPageAnimationListener animListener;

    public SlidingPage(Context context) {
        super(context);
        init(context);
    }

    public SlidingPage(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.slidingpage, this, true);

        redText = (EditText)findViewById(R.id.redText);
        yellowText = (EditText)findViewById(R.id.yellowText);
        blueText = (EditText)findViewById(R.id.blueText);

        socket = SocketClient.getClient();

        sendingButton = (Button)findViewById(R.id.sendingButton);
        sendingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                socket.sendMessage(redText.getText().toString(),yellowText.getText().toString(),blueText.getText().toString());
            }
        });

        leftAnim = AnimationUtils.loadAnimation(context, R.anim.toleft);
        rightAnim = AnimationUtils.loadAnimation(context, R.anim.toright);
        animListener = new SlidingPageAnimationListener();
        leftAnim.setAnimationListener(animListener);
        rightAnim.setAnimationListener(animListener);
        setVisibility(View.INVISIBLE);
        startAnimation(rightAnim);
    }

    private class SlidingPageAnimationListener implements Animation.AnimationListener{

        @Override
        public void onAnimationStart(Animation animation) {
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            if(isPageOpen) {
                setVisibility(View.INVISIBLE);
                isPageOpen = false;
            }
            else
                isPageOpen = true;
        }

        @Override
        public void onAnimationRepeat(Animation animation) {
        }
    }

    public void moveToLeft(){
        setVisibility(View.VISIBLE);
        startAnimation(leftAnim);
    }

    public void moveToRight(){
        startAnimation(rightAnim);
    }
}