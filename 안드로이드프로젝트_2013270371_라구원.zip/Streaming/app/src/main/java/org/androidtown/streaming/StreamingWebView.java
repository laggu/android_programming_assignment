package org.androidtown.streaming;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;

/**
 * Created by laggu on 2017-06-23.
 */

public class StreamingWebView extends WebView {

    float lastX = -1;
    SlidingPage slidingPage;

    public StreamingWebView(Context context) {
        super(context);
        init();
    }

    public StreamingWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init(){
        openWebView();
        setTouch();
    }

    public void setSlidingPage(SlidingPage slidingPage){
        this.slidingPage = slidingPage;
    }

    private void openWebView(){
        setPadding(60,60,0,60);

        getSettings().setBuiltInZoomControls(false);
        getSettings().setJavaScriptEnabled(true);
        getSettings().setLoadWithOverviewMode(true);
        getSettings().setUseWideViewPort(true);

        String url ="http://163.152.219.170:8081/javascript_simple.html";
        loadUrl(url);
    }

    private void setTouch(){
        setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                float curX = event.getX();

                switch (action){
                    case MotionEvent.ACTION_DOWN:
                        lastX = curX;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        break;
                    case MotionEvent.ACTION_UP:
                        if(lastX-curX>10) {
                           slidingPage.moveToLeft();
                        }
                        else if(curX-lastX>10)
                            slidingPage.moveToRight();
                        break;
                }
                return false;
            }
        });
    }

}