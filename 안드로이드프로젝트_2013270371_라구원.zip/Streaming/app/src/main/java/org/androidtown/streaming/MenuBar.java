package org.androidtown.streaming;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

/**
 * Created by laggu on 2017-06-24.
 */

public class MenuBar extends LinearLayout {

    ImageButton light, feeding, temperature;
    SocketClient client;
    MainActivity activity;

    public MenuBar(Context context) {
        super(context);
        init(context);
    }

    public MenuBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.menubar, this, true);

        feeding = (ImageButton)findViewById(R.id.feedingButton);
        feeding.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                client.sendMessage("2/");
            }
        });
        light = (ImageButton)findViewById(R.id.lightButton);
        light.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                client.sendMessage("3/");
            }
        });
        temperature = (ImageButton)findViewById(R.id.temperatureButton);
        temperature.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                client.sendMessage("4/");
            }
        });

        client = SocketClient.getClient();
    }

}
