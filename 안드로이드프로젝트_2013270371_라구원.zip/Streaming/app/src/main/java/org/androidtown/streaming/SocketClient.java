package org.androidtown.streaming;

import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 * Created by laggu on 2017-06-23.
 */

public class SocketClient {
    private static final int portNumber = 8082;
    private static final String address = "163.152.219.170";
    private Socket sock;
    private OutputStream os;

    private static SocketClient client;

    public static SocketClient getClient(){
        if(client==null)
            client = new SocketClient();

        return client;
    }

    private SocketClient(){
        try {

            sock = new Socket(address, portNumber);
            os = sock.getOutputStream();
        }catch(Exception e){
            Log.e("socket","not open");
            e.printStackTrace();
        }

    }

    public void sendMessage(final String red, final String yellow, final String blue){
        final String msg = "1/"+ red + "/" + yellow + "/" + blue;
        sendMessage(msg);
    }

    public void sendMessage(final String msg){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.e("send",msg);
                    final byte[] data = msg.getBytes();
                    os.write(data);
                    os.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

}
