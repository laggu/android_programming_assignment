package org.androidtown.streaming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    StreamingWebView webView;
    SlidingPage slidingPage;
    MenuBar menuBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        slidingPage = (SlidingPage)findViewById(R.id.slidingPage);
        webView = (StreamingWebView)findViewById(R.id.webView);
        webView.setSlidingPage(slidingPage);

        menuBar = (MenuBar)findViewById(R.id.menuBar);
    }

}