package org.androidtown.streaming;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Created by laggu on 2017-06-24.
 */

public class TemperatureDialog extends AppCompatActivity {
    SeekBar seekBar;
    Button checkButton, cancelButton;
    TextView seekBarValue;
    SocketClient client;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temperaturedialog);

        client = SocketClient.getClient();

        seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBarValue = (TextView) findViewById(R.id.seekBarValue);
        checkButton = (Button)findViewById(R.id.checkButton);
        cancelButton = (Button)findViewById(R.id.cancelButton);


    }
}
