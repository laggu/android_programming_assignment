package org.androidtown.quis02_02;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by laggu on 2017-05-25.
 */

public class ItemView extends LinearLayout {

    TextView nameTV, priceTV, exTV;
    ImageView imageView;

    public ItemView(Context context){
        super(context);
        init(context);
    }

    public ItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public  void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.item, this, true);

        nameTV = (TextView)findViewById(R.id.nameTextView);
        priceTV = (TextView)findViewById(R.id.priceTextView);
        exTV = (TextView)findViewById(R.id.exTextView);
        imageView = (ImageView)findViewById(R.id.image);
    }

    public void setName(String name){
        nameTV.setText(name);
    }

    public void setPrice(String price) {
        priceTV.setText(price);
    }

    public void setEx(String ex) {
        exTV.setText(ex);
    }

    public void setImageView(int resId) {
        imageView.setImageResource(resId);
    }
}
