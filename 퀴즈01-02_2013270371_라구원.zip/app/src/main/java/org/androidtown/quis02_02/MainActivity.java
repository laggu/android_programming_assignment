package org.androidtown.quis02_02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    GridView gridView;
    ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView)findViewById(R.id.gridView);
        adapter = new ItemAdapter();

        adapter.addItem(new Item("셔츠",10000,"명절기획상품",R.drawable.cloth));
        adapter.addItem(new Item("바지",20000,"특가상품",R.drawable.pants));
        adapter.addItem(new Item("신발",30000,"한정판매",R.drawable.shoes));
        adapter.addItem(new Item("썬글라스",100000,"명품특가",R.drawable.sunglasses));

        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item item = (Item)adapter.getItem(position);
                Toast.makeText(getApplicationContext(),"선택 : " + item.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class ItemAdapter extends BaseAdapter {
        ArrayList<Item> items = new ArrayList<Item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(Item item){
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ItemView view = new ItemView(getApplicationContext());
            Item item = items.get(position);
            view.setName(item.getName());
            view.setPrice(Integer.toString(item.getPrice()));
            view.setEx(item.getEx());
            view.setImageView(item.getResId());

            return view;
        }
    }
}
