package org.androidtown.quis02_02;

/**
 * Created by laggu on 2017-05-25.
 */

public class Item {
    String name, ex;
    int price, resId;


    public Item(String name, int price, String ex, int resId){
        this.price = price;
        this.name = name;
        this.ex = ex;
        this.resId = resId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEx() {
        return ex;
    }

    public void setEx(String ex) {
        this.ex = ex;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
