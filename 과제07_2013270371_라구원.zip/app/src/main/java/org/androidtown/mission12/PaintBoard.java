package org.androidtown.mission12;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by laggu on 2017-06-04.
 */

public class PaintBoard extends View {

    Canvas mCanvas;
    Bitmap mBitmap;
    final Paint mPaint, mWhite;

    int lastX;
    int lastY;
    int clickedX,clickedY;
    int flag;

    public PaintBoard(Context context) {
        super(context);

        this.mPaint = new Paint();
        this.mWhite = new Paint();
        mPaint.setColor(Color.RED);
        mWhite.setColor(Color.WHITE);

        this.lastX = 100;
        this.lastY = 100;

        Log.i("PaintBoard", "initialized.");
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        Bitmap img = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas();
        if(mBitmap == null) {
            canvas.setBitmap(img);
            canvas.drawColor(Color.WHITE);
        }
        else{
            img = mBitmap;
            canvas.setBitmap(img);
        }
        mBitmap = img;
        mCanvas = canvas;
        mCanvas.drawRect(lastX,lastY,lastX+100,lastY+100,mPaint);
    }

    protected void onDraw(Canvas canvas) {
        if (mBitmap != null) {
            canvas.drawBitmap(mBitmap, 0, 0, null);
            canvas.clipRect(lastX,lastY,lastX+100,lastY+100);
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();

        int x = (int)event.getX();
        int y = (int)event.getY();

        switch(action){
            case MotionEvent.ACTION_UP:
                flag = 0;
                break;

            case MotionEvent.ACTION_DOWN:
                if(x>=lastX && x<=lastX+100 && y>=lastY && y<=lastY+100) {
                    flag = 1;
                    clickedX = x;
                    clickedY = y;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if(flag==1) {
                    mCanvas.drawRect(lastX,lastY,lastX+100,lastY+100,mWhite);
                    lastX += (x - clickedX);
                    lastY += (y - clickedY);
                    clickedX = x;
                    clickedY = y;
                    mCanvas.drawRect(lastX,lastY,lastX+100,lastY+100,mPaint);
                }
                break;
        }

        invalidate();

        return true;
    }
}