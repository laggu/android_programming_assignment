package org.androidtown.calculator;

/**
 * Created by laggu on 2017-03-16.
 */
import java.util.Stack;
import java.util.StringTokenizer;

public class PostfixCalculator {
    private static Stack stack = new Stack();

    private static int operatorPriority(char operator) {
        if(operator == '+' || operator == '-') return 1;
        if(operator == '*' || operator == '/') return 2;
        return 3;
    }

    public static boolean isOperator(char ch) {
        return (ch == '+' || ch == '-' || ch == '*' || ch == '/');
    }

    public static boolean isNumeric(char ch) {
        return (ch >= '0' && ch <= '9') || ch =='.';
    }

    public static String postfix(String expression){
        char[] exp;
        StringBuffer sb = new StringBuffer();
        exp = expression.toCharArray();
        for(int i=0; i<exp.length; i++) {
            if(isOperator(exp[i])) {
                while(!stack.isEmpty() && operatorPriority((Character)stack.peek()) >= operatorPriority(exp[i])) {
                    sb.append(stack.pop());
                    sb.append(' ');
                }
                stack.push(exp[i]);
            } else if(isNumeric(exp[i])) {
                do {
                    sb.append(exp[i++]);
                } while(i<exp.length && isNumeric(exp[i]));
                sb.append(' '); i--;
            }
        }
        while(!stack.isEmpty()) {
            sb.append(stack.pop());
            sb.append(' ');
        }
        return sb.toString();
    }

    public static double postfixCalc(String expression){
        double num = 0.0;

        StringTokenizer stok = new StringTokenizer(expression, " " , false);
        String temp;

        while(stok.hasMoreTokens())
        {
            temp = stok.nextToken();


            if(temp.equals("+")) {
                stack.push((double)stack.pop() + (double)stack.pop());
            } else if(temp.equals("*")) {
                stack.push((double)stack.pop() * (double)stack.pop());
            } else if(temp.equals("-")) {
                num = (double)stack.pop();
                stack.push((double)stack.pop() - num);
            } else if(temp.equals("/")) {
                num = (double)stack.pop();
                stack.push((double)stack.pop() / num);
            } else{
                stack.push(Double.parseDouble(temp));
            }
        }

        return (double)stack.pop();
    }
}