package org.androidtown.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    boolean dotFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private boolean isOperator(char c){
        if(c=='+' || c=='-' || c=='*' || c=='/')
            return true;
        else
            return false;
    }

    public void onClickNumber(View v){
        Button button = (Button)v;
        textView = (TextView)findViewById(R.id.textview);
        if(textView.getText().equals("0"))
            textView.setText((String)button.getText());
        else
            textView.setText((String)textView.getText() + (String)button.getText());
    }
    public void onClickClear(View v){
        textView = (TextView)findViewById(R.id.textview);
        textView.setText("0");
    }

    public void onClickOperator(View v){
        textView = (TextView)findViewById(R.id.textview);
        Button button = (Button)v;
        String formula = textView.getText().toString();
        dotFlag = false;

        if(formula.equals("0"))
            return;
        else if(formula.charAt(formula.length()-1)=='.')
            textView.setText(formula.substring(0,formula.length()-1) + (String)button.getText());
        else if( isOperator(formula.charAt(formula.length()-1)) )
            textView.setText(formula.substring(0,formula.length()-1) + (String)button.getText());
        else
            textView.setText((String)textView.getText() + (String)button.getText());
    }

    public void onClickeDot(View v){
        textView = (TextView)findViewById(R.id.textview);
        Button button = (Button)v;
        String formula = textView.getText().toString();

        if(dotFlag)
            return;
        else if( isOperator(formula.charAt(formula.length()-1)) ) {
            textView.setText(formula + "0.");
            dotFlag = true;
        }
        else {
            textView.setText(formula+ ".");
            dotFlag = true;
        }
    }

    public void onClickeEnter(View v){
        textView = (TextView)findViewById(R.id.textview);
        String pf = PostfixCalculator.postfix(textView.getText().toString());
        textView.setText(Double.toString(PostfixCalculator.postfixCalc(pf)));
    }
}
