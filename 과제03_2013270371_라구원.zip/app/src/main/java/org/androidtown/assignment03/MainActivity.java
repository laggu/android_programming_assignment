package org.androidtown.assignment03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    TextView textView;
    Button button, button2;

    TextWatcher textWatcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText)findViewById(R.id.editText1);
        textView = (TextView)findViewById(R.id.textView);

        textWatcher = new TextWatcherImpl();

        editText.addTextChangedListener(textWatcher);

    }

    public void onClickedSubmit(View v){
        Toast.makeText(getApplicationContext(),editText.getText(),Toast.LENGTH_SHORT).show();
        editText.setText("");
        textView.setText("0 / 80 바이트");
    }

    public void onClickedFinish(View v){
        finish();
    }


    public class TextWatcherImpl implements TextWatcher{
        int textLength;
        final String addedString = " / 80 바이트";

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            textLength = s.toString().getBytes().length;
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (textLength > 80) {
                s.delete(s.length() - 1, s.length());
                textLength = s.toString().getBytes().length;
            }
            textView.setText(textLength+addedString);
        }
    }
}
