package org.androidtown.mission07;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText name, age;
    Button date, save;

    int year, month, day;
    DatePickerDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        name = (EditText) findViewById(R.id.editTextName);
        age = (EditText) findViewById(R.id.editTextAge);
        date = (Button) findViewById(R.id.buttonDate);
        save = (Button) findViewById(R.id.button);

        date.setText(year+"년 "+month+"월 "+day+"일");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "이름 : " + name.getText().toString() + "\n" + "나이 : " + age.getText().toString() + "\n" + year + "년" + month + "월" + day +"일", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int setYear, int setMonth, int setDay) {
            year = setYear;
            month = setMonth;
            day = setDay;
            date.setText(year+"년 "+month+"월 "+day+"일");
        }
    };

    public void onClicked(View v){
        dialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Dialog, listener, year , month , day);
        dialog.show();
    }
}
