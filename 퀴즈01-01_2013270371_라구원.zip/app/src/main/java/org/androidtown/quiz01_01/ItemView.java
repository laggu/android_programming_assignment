package org.androidtown.quiz01_01;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by laggu on 2017-05-25.
 */

public class ItemView extends LinearLayout {

    TextView textView;

    public ItemView(Context context){
        super(context);
        init(context);
    }

    public ItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public  void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.item, this, true);

        textView = (TextView)findViewById(R.id.textView);
    }

    public void setName(String name){
        textView.setText(name);
    }

}
