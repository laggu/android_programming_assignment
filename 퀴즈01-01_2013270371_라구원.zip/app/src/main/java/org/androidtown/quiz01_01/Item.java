package org.androidtown.quiz01_01;

/**
 * Created by laggu on 2017-05-25.
 */

public class Item {
    String name;

    public Item(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
