package org.androidtown.quiz01_01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listView);

        adapter = new ItemAdapter();

        adapter.addItem(new Item("Language & keyboard"));
        adapter.addItem(new Item("Location"));
        adapter.addItem(new Item("Accounts & sync"));
        adapter.addItem(new Item("Cloud"));
        adapter.addItem(new Item("Users"));
        adapter.addItem(new Item("olleh Two Phone service"));
        adapter.addItem(new Item("olleh Two Phone notifications"));

        listView.setAdapter(adapter);
    }

    public class ItemAdapter extends BaseAdapter {
        ArrayList<Item> items = new ArrayList<Item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(Item item){
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ItemView view = new ItemView(getApplicationContext());
            Item item = items.get(position);
            view.setName(item.getName());

            return view;
        }
    }
}
