package org.androidtown.assignement06;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;

public class MainActivity extends AppCompatActivity {
    CircleView circleView;
    private TouchHandler handler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    protected void onResume() {
        handler = new TouchHandler();
        super.onResume();
    }

    protected void onPause() {
        handler = null;
        super.onPause();
    }

    public class TouchHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            if(handler != null){
                sendMessage(obtainMessage(0));
            }


            super.handleMessage(msg);
        }

    }

}
