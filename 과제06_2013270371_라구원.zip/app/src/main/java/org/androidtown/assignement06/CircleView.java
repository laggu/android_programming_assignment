package org.androidtown.assignement06;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class CircleView extends View {

    Paint paint = new Paint();
    float circleX, circleY;
    boolean initXY = true;

    public CircleView(Context context, AttributeSet attrs) {
        super(context, attrs);

        setFocusable(true);
        setFocusableInTouchMode(true);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        paint.setColor(Color.RED);

        if(initXY) {
            circleX = getWidth() / 2;
            circleY = getHeight() * (4 / 5.0f);
            initXY = !initXY;
        }

        canvas.drawCircle(circleX, circleY,
                50, paint);
    }

    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        if(event.getAction() == MotionEvent.ACTION_DOWN) {
            if(x<getWidth()/2 && y>circleY){
                circleX -= 10;
            }
            else if(x>getWidth()/2 && y>circleY){
                circleX += 10;
            }
            else {
                circleY -= 20;
                invalidate();

                circleY += 20;
            }
        }
        invalidate();
        return super.onTouchEvent(event);
    }
}